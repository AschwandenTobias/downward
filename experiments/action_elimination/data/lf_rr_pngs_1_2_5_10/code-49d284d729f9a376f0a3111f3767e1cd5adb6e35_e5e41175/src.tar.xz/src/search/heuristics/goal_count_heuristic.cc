#include "goal_count_heuristic.h"

#include "../plugins/plugin.h"
#include "../utils/logging.h"
#include "../utils/markup.h"

#include <iostream>
using namespace std;

namespace goal_count_heuristic {
GoalCountHeuristic::GoalCountHeuristic(
    const shared_ptr<AbstractTask> &task, bool cache_estimates,
    const string &description, utils::Verbosity verbosity)
    : Heuristic(task, cache_estimates, description, verbosity) {
    if (log.is_at_least_normal()) {
        log << "Initializing goal count heuristic..." << endl;
    }
}

int GoalCountHeuristic::compute_heuristic(const State &ancestor_state) {
    State state = convert_ancestor_state(ancestor_state);
    int unsatisfied_goal_count = 0;

    for (FactProxy goal : task_proxy.get_goals()) {
        const VariableProxy var = goal.get_variable();
        if (state[var] != goal) {
            ++unsatisfied_goal_count;
        }
    }
    return unsatisfied_goal_count;
}

class GoalCountHeuristicFeature
    : public plugins::TypedFeature<TaskIndependentEvaluator> {
public:
    GoalCountHeuristicFeature() : TypedFeature("goalcount") {
        document_title("Goal count heuristic");
        document_synopsis(
            "Counts the goal facts that are not true in the current state. "
            "An early use of the number of remaining goals to guide planning "
            "search is described in the following article:" +
            utils::format_journal_reference(
                {"Richard E. Fikes", "Nils J. Nilsson"},
                "STRIPS: A New Approach to the Application of Theorem Proving "
                "to Problem Solving",
                "https://doi.org/10.1016/0004-3702%2871%2990010-5",
                "Artificial Intelligence", "2(3-4)", "189-208", "1971"));

        add_heuristic_options_to_feature(*this, "goalcount");

        document_language_support("action costs", "ignored by design");
        document_language_support("conditional effects", "supported");
        document_language_support("axioms", "supported");

        document_property("admissible", "no");
        document_property("consistent", "no");
        document_property("safe", "yes");
        document_property("preferred operators", "no");
    }

    virtual shared_ptr<TaskIndependentEvaluator> create_component(
        const plugins::Options &opts) const override {
        return components::make_auto_task_independent_component<
            GoalCountHeuristic, Evaluator>(
            get_heuristic_arguments_from_options(opts));
    }
};

static plugins::FeaturePlugin<GoalCountHeuristicFeature> _plugin;
}
