#include "pattern_generator_greedy.h"

#include "pattern_information.h"
#include "utils.h"

#include "../task_proxy.h"

#include "../plugins/plugin.h"
#include "../task_utils/variable_order_finder.h"
#include "../utils/logging.h"
#include "../utils/markup.h"
#include "../utils/math.h"
#include "../utils/timer.h"

#include <iostream>

using namespace std;

namespace pdbs {
PatternGeneratorGreedy::PatternGeneratorGreedy(
    const shared_ptr<AbstractTask> &task, int max_states,
    utils::Verbosity verbosity)
    : PatternGenerator(task, verbosity), max_states(max_states) {
}

string PatternGeneratorGreedy::name() const {
    return "greedy pattern generator";
}

PatternInformation PatternGeneratorGreedy::compute_pattern(
    const shared_ptr<AbstractTask> &task) {
    TaskProxy task_proxy(*task);
    Pattern pattern;
    variable_order_finder::VariableOrderFinder order(
        task_proxy, variable_order_finder::GOAL_CG_LEVEL);
    VariablesProxy variables = task_proxy.get_variables();

    int size = 1;
    while (true) {
        if (order.done())
            break;
        int next_var_id = order.next();
        VariableProxy next_var = variables[next_var_id];
        int next_var_size = next_var.get_domain_size();

        if (!utils::is_product_within_limit(size, next_var_size, max_states))
            break;

        pattern.push_back(next_var_id);
        size *= next_var_size;
    }

    return PatternInformation(task_proxy, move(pattern), log);
}

class PatternGeneratorGreedyFeature
    : public plugins::TypedFeature<TaskIndependentPatternGenerator> {
public:
    PatternGeneratorGreedyFeature() : TypedFeature("greedy") {
        document_title("Greedy");
        document_synopsis(
            "This generator adds variables in the GOAL_CG_LEVEL order until "
            "the size limit is reached. The variable ordering is described "
            "in the following paper:" +
            utils::format_conference_reference(
                {"Malte Helmert", "Patrik Haslum", "Jörg Hoffmann"},
                "Flexible Abstraction Heuristics for Optimal Sequential "
                "Planning",
                "https://cdn.aaai.org/ICAPS/2007/ICAPS07-023.pdf",
                "Proceedings of the 17th International Conference on "
                "Automated Planning and Scheduling (ICAPS 2007)",
                "176-183", "AAAI Press", "2007"));
        add_option<int>(
            "max_states",
            "maximal number of abstract states in the pattern database.",
            "1000000", plugins::Bounds("1", "infinity"));
        add_generator_options_to_feature(*this);
    }

    virtual shared_ptr<TaskIndependentPatternGenerator> create_component(
        const plugins::Options &opts) const override {
        return components::make_auto_task_independent_component<
            PatternGeneratorGreedy, PatternGenerator>(
            opts.get<int>("max_states"),
            get_generator_arguments_from_options(opts));
    }
};

static plugins::FeaturePlugin<PatternGeneratorGreedyFeature> _plugin;
}
