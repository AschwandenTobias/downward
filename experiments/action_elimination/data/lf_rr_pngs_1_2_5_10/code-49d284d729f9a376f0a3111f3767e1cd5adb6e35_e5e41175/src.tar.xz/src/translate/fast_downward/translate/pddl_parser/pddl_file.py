from fast_downward.translate.pddl_parser import lisp_parser
from fast_downward.translate.pddl_parser import parse_error
from fast_downward.translate.pddl_parser import parsing_functions

file_open = open


def parse_pddl_file(type, filename):
    try:
        # The builtin open function is shadowed by this module's open function.
        # We use the Latin-1 encoding (which allows a superset of ASCII, of the
        # Latin-* encodings and of UTF-8) to allow special characters in
        # comments. In all other parts, we later validate that only ASCII is
        # used.
        return lisp_parser.parse_nested_list(file_open(filename,
                                                       encoding='ISO-8859-1'))
    except OSError as e:
        raise SystemExit("Error: Could not read file: %s\nReason: %s" %
                         (e.filename, e))
    except parse_error.ParseError as e:
        raise parse_error.ParseError("Error: Could not parse %s file: %s\nReason: %s" %
                         (type, filename, e))


def open(domain_filename=None, problem_filename=None):
    if domain_filename is None or problem_filename is None:
        # Importing options triggers parsing the problem and domain file names
        # as arguments from the command line. We don't import unconditionally
        # at the head of this file because open is exposed in __init__.py
        # and as a result importing anything of the pddl_parser package in
        # external code would then trigger this arg parse.
        from fast_downward.translate.options import get_options
        domain_filename = domain_filename or get_options().domain
        problem_filename = problem_filename or get_options().problem

    domain_pddl = parse_pddl_file("domain", domain_filename)
    problem_pddl = parse_pddl_file("problem", problem_filename)

    return parsing_functions.parse_task(domain_pddl, problem_pddl)
