<img src="misc/images/fast-downward.svg" width="800" alt="Fast Downward">

Fast Downward is a domain-independent classical planning system.

Copyright 2003-2026 Fast Downward contributors (see below).

For further information:
- Fast Downward website: <https://www.fast-downward.org>
- Report a bug or file an issue: <https://issues.fast-downward.org>
- Fast Downward mailing list: <https://groups.google.com/forum/#!forum/fast-downward>
- Fast Downward main repository: <https://github.com/aibasel/downward>


## Scientific experiments

We recommend to use the [latest
release](https://github.com/aibasel/downward/releases/latest) instead
of the tip of the main branch. The [Downward
Lab](https://lab.readthedocs.io/en/stable/) Python package helps
running Fast Downward experiments. Our separate [benchmark
repository](https://github.com/aibasel/downward-benchmarks) contains a
collection of planning tasks.


## Supported software versions

The planner is mainly developed under Linux; and all of its features
should work with no restrictions under this platform. The planner
should compile and run correctly on macOS, but we cannot guarantee
that it works as well as under Linux. The same comment applies for
Windows, where additionally some diagnostic features (e.g., reporting
peak memory usage when the planner is terminated by a signal) are not
supported. Setting time and memory limits and running portfolios is
not supported under Windows either.

This version of Fast Downward has been tested with the following software versions:

| OS           | Python | C++ compiler                               | CMake |
| ------------ | ------ | ------------------------------------------ | ----- |
| Ubuntu 26.04 | 3.14   | GCC 15, GCC 16, Clang 21, Clang 22         | 4.2   |
| Ubuntu 24.04 | 3.12   | GCC 14, Clang 20                           | 3.31  |
| macOS 15     | 3.14   | AppleClang 17                              | 4.2   |
| macOS 14     | 3.14   | AppleClang 15                              | 4.2   |
| Windows 10   | 3.9    | Visual Studio Enterprise 2022 (MSVC 19.44) | 3.31  |

We test LP support with CPLEX 22.1.1 and SoPlex 7.1.2. On Ubuntu we
test both CPLEX and SoPlex. On Windows we currently only test CPLEX,
and on macOS we do not test LP solvers (yet).


## Build instructions

See [BUILD.md](BUILD.md).


## Contributors

The following list includes all people that actively contributed to
Fast Downward, i.e., all people that appear in some commits in Fast
Downward's history (see below for a history on how Fast Downward
emerged) or people that influenced the development of such commits.
Currently, this list is sorted by the last year the person has been
active, and in case of ties, by the earliest year the person started
contributing, and finally by last name.

- 2003-2026 Malte Helmert
- 2008-2016, 2018-2026 Gabriele Röger
- 2012-2026 Florian Pommerening
- 2021-2026 Clemens Büchner
- 2022-2026 Remo Christen
- 2022-2026 Simon Dold
- 2023-2026 Claudia S. Grundke
- 2024-2026 Tanja Schindler
- 2024-2026 David Speck
- 2025-2026 Esther Mugdan
- 2025-2026 Travis Rivera Petit
- 2026 Gustavo Delazeri
- 2026 Pascal Lauer
- 2009, 2025 Christian Muise
- 2010-2025 Jendrik Seipp
- 2010-2011, 2013-2025 Silvan Sievers
- 2013, 2015-2025 Salomé Eriksson
- 2018-2024 Patrick Ferber
- 2024 Martín Pozo
- 2015, 2021-2023 Thomas Keller
- 2018-2020, 2023 Augusto B. Corrêa
- 2023 Victor Paléologue
- 2023 Emanuele Tirendi
- 2021-2022 Dominik Drexler
- 2016-2020 Cedric Geissmann
- 2017-2020 Guillem Francès
- 2020 Rik de Graaff
- 2015-2019 Manuel Heusner
- 2017 Daniel Killenberger
- 2016 Yusra Alkhazraji
- 2016 Martin Wehrle
- 2014-2015 Patrick von Reth
- 2009-2014 Erez Karpas
- 2014 Robert P. Goldman
- 2010-2012 Andrew Coles
- 2010, 2012 Patrik Haslum
- 2003-2011 Silvia Richter
- 2009-2011 Emil Keyder
- 2010-2011 Moritz Gronbach
- 2010-2011 Manuela Ortlieb
- 2011 Vidal Alcázar Saiz
- 2011 Michael Katz
- 2011 Raz Nissim
- 2010 Moritz Goebelbecker
- 2007-2009 Matthias Westphal


## History

The current version of Fast Downward is the merger of three different
projects:

- the original version of Fast Downward developed by Malte Helmert
  and Silvia Richter
- LAMA, developed by Silvia Richter and Matthias Westphal based on
  the original Fast Downward
- FD-Tech, a modified version of Fast Downward developed by Erez
  Karpas and Michael Katz based on the original code

In addition to these three main sources, the codebase incorporates
code and features from numerous branches of the Fast Downward codebase
developed for various research papers. The main contributors to these
branches are Malte Helmert, Gabi Röger and Silvia Richter.


## License

```
Fast Downward is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at
your option) any later version.

Fast Downward is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
```
